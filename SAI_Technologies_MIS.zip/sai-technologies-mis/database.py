"""SQLite database layer: schema, seed data and simple queries."""
import sqlite3

MACHINES = ["CNC-01", "CNC-02", "Press-01", "Lathe-01"]
SHIFTS = ["Shift A", "Shift B", "Shift C"]
DEFECTS = ["Dimension error", "Surface scratch", "Burr / Flash", "Material defect", "Assembly error"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS machines(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS defect_reasons(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS production_entries(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT NOT NULL,
    shift TEXT NOT NULL CHECK(shift IN ('Shift A','Shift B','Shift C')),
    machine_id INTEGER NOT NULL REFERENCES machines(id),
    defect_id INTEGER NOT NULL REFERENCES defect_reasons(id),
    produced INTEGER NOT NULL CHECK(produced > 0),
    rejected INTEGER NOT NULL CHECK(rejected >= 0 AND rejected <= produced),
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_entries_date ON production_entries(entry_date);
"""


def connect(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(path):
    conn = connect(path)
    conn.executescript(SCHEMA)
    conn.executemany("INSERT OR IGNORE INTO machines(name) VALUES(?)", [(m,) for m in MACHINES])
    conn.executemany("INSERT OR IGNORE INTO defect_reasons(name) VALUES(?)", [(d,) for d in DEFECTS])
    conn.commit()
    conn.close()


def fetch_entries(conn, date_from=None, date_to=None):
    sql = """SELECT e.id, e.entry_date AS date, e.shift, m.name AS machine, d.name AS defect,
                    e.produced, e.rejected
             FROM production_entries e
             JOIN machines m ON m.id = e.machine_id
             JOIN defect_reasons d ON d.id = e.defect_id
             WHERE (? IS NULL OR e.entry_date >= ?) AND (? IS NULL OR e.entry_date <= ?)
             ORDER BY e.entry_date, e.id"""
    a, b = date_from or None, date_to or None
    return [dict(r) for r in conn.execute(sql, (a, a, b, b))]


def insert_entry(conn, c):
    cur = conn.execute(
        """INSERT INTO production_entries(entry_date, shift, machine_id, defect_id, produced, rejected)
           VALUES(?, ?, (SELECT id FROM machines WHERE name=?),
                  (SELECT id FROM defect_reasons WHERE name=?), ?, ?)""",
        (c["date"], c["shift"], c["machine"], c["defect"], c["produced"], c["rejected"]))
    return cur.lastrowid


def delete_entry(conn, entry_id):
    return conn.execute("DELETE FROM production_entries WHERE id=?", (entry_id,)).rowcount


def clear_entries(conn):
    return conn.execute("DELETE FROM production_entries").rowcount
