"""Core business logic: KPIs, Pareto analysis, performance tables, trend and report."""
from datetime import datetime


def pct(part, whole):
    return round(part / whole * 100, 2) if whole else 0.0


def summary(rows, limit=5.0, daily_target=0, cost_per_unit=0):
    produced = sum(r["produced"] for r in rows)
    rejected = sum(r["rejected"] for r in rows)
    days = len({r["date"] for r in rows})
    target = days * daily_target
    rej = pct(rejected, produced)
    return {
        "total_produced": produced,
        "total_rejected": rejected,
        "rejection_pct": rej,
        "good_output_pct": round(100 - rej, 2) if produced else 0.0,
        "target_achieved_pct": pct(produced, target),
        "rejection_cost": round(rejected * cost_per_unit),
        "limit_pct": limit,
        "alert": rej > limit,
    }


def pareto(rows):
    totals = {}
    for r in rows:
        totals[r["defect"]] = totals.get(r["defect"], 0) + r["rejected"]
    ordered = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
    all_rejected, running, out = sum(totals.values()), 0, []
    for name, count in ordered:
        running += count
        out.append({"reason": name, "rejected": count, "cumulative_pct": round(pct(running, all_rejected))})
    return out


def performance(rows, key):
    groups = {}
    for r in rows:
        g = groups.setdefault(r[key], {"produced": 0, "rejected": 0})
        g["produced"] += r["produced"]
        g["rejected"] += r["rejected"]
    return [{"name": k, "produced": v["produced"], "rejected": v["rejected"],
             "rejection_pct": pct(v["rejected"], v["produced"])} for k, v in sorted(groups.items())]


def trend(rows):
    days = performance(rows, "date")
    return [{"date": d["name"], "rejection_pct": d["rejection_pct"]} for d in days]


def report(rows, limit=5.0, cost_per_unit=0):
    if not rows:
        raise ValueError("No data for the selected period")
    s = summary(rows, limit, 0, cost_per_unit)
    p = pareto(rows)
    top = p[0] if p and p[0]["rejected"] else {"reason": "None", "rejected": 0}
    machines = performance(rows, "machine")
    worst = max(machines, key=lambda m: m["rejection_pct"])
    dates = sorted(r["date"] for r in rows)
    return {
        "period_start": dates[0], "period_end": dates[-1],
        "generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "produced": s["total_produced"], "rejected": s["total_rejected"],
        "rejection_pct": s["rejection_pct"],
        "status": f"Rejection is {'above' if s['alert'] else 'within'} the {limit:g}% limit.",
        "cost": s["rejection_cost"],
        "top_defect": {"reason": top["reason"], "rejected": top["rejected"],
                       "share_pct": round(pct(top["rejected"], s["total_rejected"]))},
        "machines": machines,
        "action": f"Review {top['reason'].lower()} on {worst['name']} (highest rejection %).",
    }
