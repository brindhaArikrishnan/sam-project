import unittest
from datetime import date, timedelta
import logic
from validators import validate_entry
import database as db

ROWS = [
    {"date": "2026-11-20", "shift": "Shift A", "machine": "CNC-01", "defect": "Dimension error", "produced": 100, "rejected": 10},
    {"date": "2026-11-20", "shift": "Shift B", "machine": "Press-01", "defect": "Burr / Flash", "produced": 100, "rejected": 5},
    {"date": "2026-11-21", "shift": "Shift A", "machine": "CNC-01", "defect": "Dimension error", "produced": 200, "rejected": 5},
]


def good(**kw):
    d = {"date": "2026-11-20", "shift": "Shift A", "machine": "CNC-01", "defect": "Dimension error",
         "produced": 100, "rejected": 5}
    d.update(kw)
    return d


class ValidationTests(unittest.TestCase):
    def check(self, data):
        return validate_entry(data, db.MACHINES, db.SHIFTS, db.DEFECTS)[1]

    def test_valid_entry(self):
        self.assertEqual(self.check(good()), [])

    def test_rejected_more_than_produced(self):
        self.assertTrue(self.check(good(rejected=101)))

    def test_zero_or_text_produced(self):
        self.assertTrue(self.check(good(produced=0)))
        self.assertTrue(self.check(good(produced="abc")))

    def test_negative_rejected(self):
        self.assertTrue(self.check(good(rejected=-1)))

    def test_bad_date_and_future_date(self):
        self.assertTrue(self.check(good(date="20-11-2026")))
        self.assertTrue(self.check(good(date=(date.today() + timedelta(days=2)).isoformat())))

    def test_unknown_machine_shift_defect(self):
        self.assertTrue(self.check(good(machine="X-99")))
        self.assertTrue(self.check(good(shift="Shift Z")))
        self.assertTrue(self.check(good(defect="Rust")))


class LogicTests(unittest.TestCase):
    def test_summary(self):
        s = logic.summary(ROWS, limit=5, daily_target=200, cost_per_unit=100)
        self.assertEqual(s["total_produced"], 400)
        self.assertEqual(s["total_rejected"], 20)
        self.assertEqual(s["rejection_pct"], 5.0)
        self.assertFalse(s["alert"])  # 5.0 is not above the 5% limit
        self.assertEqual(s["target_achieved_pct"], 100.0)  # 2 days x 200
        self.assertEqual(s["rejection_cost"], 2000)

    def test_alert_when_above_limit(self):
        self.assertTrue(logic.summary(ROWS, limit=3)["alert"])

    def test_empty_data_does_not_crash(self):
        s = logic.summary([])
        self.assertEqual(s["rejection_pct"], 0.0)

    def test_pareto_sorted_and_cumulative(self):
        p = logic.pareto(ROWS)
        self.assertEqual(p[0]["reason"], "Dimension error")
        self.assertEqual(p[0]["rejected"], 15)
        self.assertEqual(p[-1]["cumulative_pct"], 100)

    def test_performance_by_machine(self):
        m = {x["name"]: x for x in logic.performance(ROWS, "machine")}
        self.assertEqual(m["CNC-01"]["rejection_pct"], 5.0)
        self.assertEqual(m["Press-01"]["rejection_pct"], 5.0)

    def test_report(self):
        r = logic.report(ROWS, limit=5)
        self.assertEqual(r["top_defect"]["reason"], "Dimension error")
        self.assertEqual(r["period_start"], "2026-11-20")
        with self.assertRaises(ValueError):
            logic.report([])


if __name__ == "__main__":
    unittest.main()
