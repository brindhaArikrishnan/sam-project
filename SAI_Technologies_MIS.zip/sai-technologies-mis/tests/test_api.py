import os, tempfile, unittest
from app import create_app

MANAGER = {"X-Role": "Manager"}
OPERATOR = {"X-Role": "Operator"}


def entry(**kw):
    d = {"date": "2026-11-20", "shift": "Shift A", "machine": "CNC-01", "defect": "Burr / Flash",
         "produced": 100, "rejected": 5}
    d.update(kw)
    return d


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.client = create_app(os.path.join(self.tmp, "test.db")).test_client()

    def test_add_and_list(self):
        r = self.client.post("/api/entries", json=entry(), headers=OPERATOR)
        self.assertEqual(r.status_code, 201)
        rows = self.client.get("/api/entries").get_json()["entries"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["machine"], "CNC-01")

    def test_invalid_entry_rejected_with_400(self):
        r = self.client.post("/api/entries", json=entry(rejected=500), headers=OPERATOR)
        self.assertEqual(r.status_code, 400)
        self.assertIn("rejected cannot be more than produced", r.get_json()["errors"])
        self.assertEqual(self.client.get("/api/entries").get_json()["entries"], [])

    def test_operator_cannot_delete_manager_can(self):
        eid = self.client.post("/api/entries", json=entry(), headers=OPERATOR).get_json()["id"]
        self.assertEqual(self.client.delete(f"/api/entries/{eid}", headers=OPERATOR).status_code, 403)
        self.assertEqual(self.client.delete(f"/api/entries/{eid}", headers=MANAGER).status_code, 200)
        self.assertEqual(self.client.delete(f"/api/entries/{eid}", headers=MANAGER).status_code, 404)

    def test_summary_pareto_report(self):
        self.client.post("/api/entries", json=entry(produced=100, rejected=10), headers=OPERATOR)
        self.client.post("/api/entries", json=entry(produced=100, rejected=2, defect="Surface scratch"), headers=OPERATOR)
        s = self.client.get("/api/summary?limit=5&cost=100").get_json()
        self.assertEqual(s["rejection_pct"], 6.0)
        self.assertTrue(s["alert"])
        self.assertEqual(s["rejection_cost"], 1200)
        p = self.client.get("/api/pareto").get_json()["pareto"]
        self.assertEqual(p[0]["reason"], "Burr / Flash")
        r = self.client.get("/api/report?limit=5").get_json()
        self.assertEqual(r["rejected"], 12)

    def test_report_with_no_data_is_400(self):
        self.assertEqual(self.client.get("/api/report").status_code, 400)

    def test_date_filter(self):
        self.client.post("/api/entries", json=entry(date="2026-11-01"), headers=OPERATOR)
        self.client.post("/api/entries", json=entry(date="2026-11-20"), headers=OPERATOR)
        rows = self.client.get("/api/entries?from=2026-11-10").get_json()["entries"]
        self.assertEqual([r["date"] for r in rows], ["2026-11-20"])

    def test_import_skips_bad_rows(self):
        body = {"rows": [entry(), entry(produced="x"), entry(machine="nope")]}
        self.assertEqual(self.client.post("/api/entries/import", json=body, headers=OPERATOR).status_code, 403)
        j = self.client.post("/api/entries/import", json=body, headers=MANAGER).get_json()
        self.assertEqual(j["inserted"], 1)
        self.assertEqual([x["row"] for x in j["skipped"]], [2, 3])

    def test_demo_and_export(self):
        self.assertEqual(self.client.post("/api/demo", headers=MANAGER).status_code, 201)
        csv_text = self.client.get("/api/export.csv").get_data(as_text=True)
        self.assertEqual(len(csv_text.strip().splitlines()), 25)  # header + 24 rows

    def test_index_page_served(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Rejection Report", r.data)


if __name__ == "__main__":
    unittest.main()
