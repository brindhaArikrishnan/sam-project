# SAI Technologies: Automated Manufacturing MIS and Rejection Report Generator

Sprint Week 2: Core Engineering & Data Layer Integration

A Flask + SQLite web app. Operators log production and rejection data; the server validates it, stores it in a database, and produces KPIs, Pareto analysis, machine/shift performance, and a rejection report.

## Run it

```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser and click **Load sample data**.

## Run the tests

```
python -m unittest discover
```

## Project structure

| File | Purpose |
|---|---|
| `app.py` | Flask app: REST API and web page |
| `database.py` | SQLite schema, seed data, queries |
| `validators.py` | Server-side input validation |
| `logic.py` | Core business logic (KPIs, Pareto, performance, trend, report) |
| `static/index.html` | Web UI (calls the API) |
| `tests/` | Unit tests for validation, logic and API |

## Database schema (SQLite)

- `machines(id, name)`
- `defect_reasons(id, name)`
- `production_entries(id, entry_date, shift, machine_id, defect_id, produced, rejected, created_at)`
  with constraints: `produced > 0`, `0 <= rejected <= produced`, valid shift, foreign keys to machines and defects.

## API

| Method | Endpoint | Role | Description |
|---|---|---|---|
| GET | `/api/meta` | any | machines, shifts, defect reasons |
| GET | `/api/entries?from=&to=` | any | list entries (optional date range) |
| POST | `/api/entries` | any | add entry (validated, 400 with error list if invalid) |
| DELETE | `/api/entries/<id>` | Manager | delete one entry |
| DELETE | `/api/entries` | Manager | delete all entries |
| POST | `/api/entries/import` | Manager | bulk import rows, bad rows are skipped and reported |
| POST | `/api/demo` | Manager | load 24 sample entries |
| GET | `/api/summary?limit=&target=&cost=` | any | KPIs and alert flag |
| GET | `/api/pareto` | any | defects ranked with cumulative % |
| GET | `/api/performance?by=machine\|shift` | any | rejection % per machine or shift |
| GET | `/api/trend` | any | daily rejection % |
| GET | `/api/report?limit=&cost=` | any | full rejection report data |
| GET | `/api/export.csv` | any | download data as CSV |

The role is sent in the `X-Role` header (Manager / Supervisor / Operator). This is a prototype access check; real login is planned.

## Validation rules

Date must be `YYYY-MM-DD` and not in the future; shift, machine and defect must be from the allowed lists; produced is a whole number from 1 to 1,000,000; rejected is a whole number from 0 to produced.

## Future scope

Real user login, PostgreSQL, Excel export, email/WhatsApp alerts, AI rejection prediction, IoT sensor input.
