"""SAI Technologies MIS: Flask backend (REST API + serves the web UI)."""
import csv, io, os, random
from contextlib import closing
from datetime import date, timedelta
from flask import Flask, jsonify, request, Response

import database as db
import logic
from validators import validate_entry

BASE = os.path.dirname(os.path.abspath(__file__))


def create_app(db_path=None):
    app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
    app.config["DB"] = db_path or os.path.join(BASE, "mis.db")
    db.init_db(app.config["DB"])

    def conn():
        return closing(db.connect(app.config["DB"]))

    def role():
        return request.headers.get("X-Role", "Operator")  # least privilege by default

    def forbidden():
        return jsonify(error=f"Role '{role()}' is not allowed to do this. Manager only."), 403

    def number(name, default):
        try:
            return float(request.args.get(name, default))
        except ValueError:
            raise ValueError(f"{name} must be a number")

    def period_rows(c):
        return db.fetch_entries(c, request.args.get("from"), request.args.get("to"))

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    @app.get("/api/meta")
    def meta():
        return jsonify(machines=db.MACHINES, shifts=db.SHIFTS, defects=db.DEFECTS)

    @app.get("/api/entries")
    def list_entries():
        with conn() as c:
            return jsonify(entries=period_rows(c))

    @app.post("/api/entries")
    def add_entry():
        clean, errors = validate_entry(request.get_json(silent=True) or {}, db.MACHINES, db.SHIFTS, db.DEFECTS)
        if errors:
            return jsonify(errors=errors), 400
        with conn() as c:
            clean["id"] = db.insert_entry(c, clean)
            c.commit()
        return jsonify(clean), 201

    @app.delete("/api/entries/<int:entry_id>")
    def remove_entry(entry_id):
        if role() != "Manager":
            return forbidden()
        with conn() as c:
            n = db.delete_entry(c, entry_id)
            c.commit()
        return (jsonify(deleted=entry_id), 200) if n else (jsonify(error="Entry not found"), 404)

    @app.delete("/api/entries")
    def remove_all():
        if role() != "Manager":
            return forbidden()
        with conn() as c:
            n = db.clear_entries(c)
            c.commit()
        return jsonify(deleted=n)

    @app.post("/api/entries/import")
    def import_entries():
        if role() != "Manager":
            return forbidden()
        rows = (request.get_json(silent=True) or {}).get("rows")
        if not isinstance(rows, list) or len(rows) > 5000:
            return jsonify(error="Send {'rows': [...]} with at most 5000 rows"), 400
        inserted, skipped = 0, []
        with conn() as c:
            for i, row in enumerate(rows, start=1):
                clean, errors = validate_entry(row if isinstance(row, dict) else {}, db.MACHINES, db.SHIFTS, db.DEFECTS)
                if errors:
                    skipped.append({"row": i, "errors": errors})
                else:
                    db.insert_entry(c, clean)
                    inserted += 1
            c.commit()
        return jsonify(inserted=inserted, skipped=skipped)

    @app.post("/api/demo")
    def demo():
        if role() != "Manager":
            return forbidden()
        weights = [5, 3, 2, 1, 1]
        with conn() as c:
            for i in range(24):
                machine = db.MACHINES[i % 4]
                produced = random.randint(300, 600)
                rate = 0.08 if machine == "Press-01" else 0.025
                db.insert_entry(c, {
                    "date": (date.today() - timedelta(days=i // 4)).isoformat(),
                    "shift": db.SHIFTS[i % 3], "machine": machine,
                    "defect": random.choices(db.DEFECTS, weights)[0],
                    "produced": produced, "rejected": int(produced * rate * random.uniform(0.5, 1.5))})
            c.commit()
        return jsonify(inserted=24), 201

    @app.get("/api/summary")
    def get_summary():
        try:
            args = (number("limit", 5), number("target", 0), number("cost", 0))
        except ValueError as e:
            return jsonify(error=str(e)), 400
        with conn() as c:
            return jsonify(logic.summary(period_rows(c), *args))

    @app.get("/api/pareto")
    def get_pareto():
        with conn() as c:
            return jsonify(pareto=logic.pareto(period_rows(c)))

    @app.get("/api/performance")
    def get_performance():
        by = request.args.get("by", "machine")
        if by not in ("machine", "shift"):
            return jsonify(error="by must be 'machine' or 'shift'"), 400
        with conn() as c:
            return jsonify(performance=logic.performance(period_rows(c), by))

    @app.get("/api/trend")
    def get_trend():
        with conn() as c:
            return jsonify(trend=logic.trend(period_rows(c)))

    @app.get("/api/report")
    def get_report():
        try:
            limit, cost = number("limit", 5), number("cost", 0)
            with conn() as c:
                return jsonify(logic.report(period_rows(c), limit, cost))
        except ValueError as e:
            return jsonify(error=str(e)), 400

    @app.get("/api/export.csv")
    def export_csv():
        with conn() as c:
            rows = period_rows(c)
        out = io.StringIO()
        w = csv.writer(out)
        w.writerow(["date", "shift", "machine", "produced", "rejected", "defect"])
        w.writerows([[r["date"], r["shift"], r["machine"], r["produced"], r["rejected"], r["defect"]] for r in rows])
        return Response(out.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=rejection_data.csv"})

    @app.errorhandler(404)
    def not_found(_):
        return jsonify(error="Not found"), 404

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
