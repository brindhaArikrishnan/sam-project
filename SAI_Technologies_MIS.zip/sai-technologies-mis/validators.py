"""Server-side input validation. Never trust the browser."""
from datetime import date


def _whole_number(value, name, errors):
    try:
        return int(str(value).strip())
    except (ValueError, TypeError):
        errors.append(f"{name} must be a whole number")
        return None


def validate_entry(data, machines, shifts, defects):
    """Return (clean_entry, errors). errors is an empty list when the entry is valid."""
    errors, clean = [], {}
    text = str(data.get("date", "")).strip()
    try:
        d = date.fromisoformat(text) if len(text) == 10 else None
        if d is None:
            raise ValueError
        if d > date.today():
            errors.append("date cannot be in the future")
        clean["date"] = text
    except ValueError:
        errors.append("date must be in YYYY-MM-DD format")

    for field, allowed in (("shift", shifts), ("machine", machines), ("defect", defects)):
        value = str(data.get(field, "")).strip()
        if value not in allowed:
            errors.append(f"{field} must be one of: {', '.join(allowed)}")
        clean[field] = value

    produced = _whole_number(data.get("produced"), "produced", errors)
    rejected = _whole_number(data.get("rejected", 0), "rejected", errors)
    if produced is not None and not 1 <= produced <= 1_000_000:
        errors.append("produced must be between 1 and 1,000,000")
    if rejected is not None and rejected < 0:
        errors.append("rejected cannot be negative")
    if produced is not None and rejected is not None and rejected > produced:
        errors.append("rejected cannot be more than produced")
    clean["produced"], clean["rejected"] = produced, rejected
    return clean, errors
